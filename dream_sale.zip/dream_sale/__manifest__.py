{
    'name': "Dream Sale",
    'author': "Ko Phyo",

    'website': "dream.fiberinternet@gmial.com",
    'category': "Sale",
    'summary': """
        Dream Eleven Co,LTD.
    """,

    'description': """
        Dream Elevens Internet Services Provider
            - Upgrade your life with Dream FTTH Services
    """,

    'data': [
        'security/ir.model.access.csv',
    ],
}