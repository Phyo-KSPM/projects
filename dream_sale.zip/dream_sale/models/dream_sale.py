import string
from odoo import models, fields

class DreamSale(models.Model):
    _name = 'dream.sale'


    image = fields.Binary(string="CV Image", attachment=True)
    name = fields.Char(string="Name")
    customer_types = fields.Selection([
        ('home', 'အိမ်သုံး'),
        ('shop', 'ဆိုင်သုံး')
    ], string="Customer Types", default="home", required=True)
    billing_contact_name = fields.Char(string="Billing Contact Name", required=True)
    phone = fields.Char(string="Phone", required=True)
    mobile = fields.Char(string="Mobile")

    nrc = fields.Char(string="NRC")
    customer_latlong = fields.Char(string="Customer Latlong", required=True)
    address = fields.Text(string="Address", required=True)
    package = fields.Selection([
        ('10mbps', '10 Mbps'),
        ('15mbps', '15 Mbps'),
        ('20mbps', '20 Mbps'),
        ('30mbps', '30 Mbps')
    ], string="Package" ,required=True)
    contract_month = fields.Selection([
        ('1month','1 Month'),
        ('3months','3 Months'),
        ('6months','6 Months')
    ], string="Contract Month", default="1month", required=True)

    start_date = fields.Date(string="Start Date", required=True)
    expired_date = fields.Date(string="Expired Date")
    