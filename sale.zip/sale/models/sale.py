import string
from odoo import models, fields, api, _

class Sale(models.Model):
    _name='sale'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    active = fields.Boolean(string="Active", default=True, track_visibility="always")
    image = fields.Binary(string="CS Image", attachment=True, track_visibility="always")
    customer_id = fields.Char(string="Customer ID", readonly=True, track_visibility="always")
    name = fields.Char(string="Name", track_visibility="always")
    customer_types = fields.Selection([
        ('home', 'အိမ်သုံး'),
        ('shop', 'ဆိုင်သုံး')
    ], string="Customer Type", default="home", required=True, track_visibility="always")

    billing_contact_name = fields.Char(string="Billing Contact Name", required=True, track_visibility="always")
    phone = fields.Char(string="Phone", required=True, track_visibility="always")
    mobile = fields.Char(string="Mobile", track_visibility="always")
    cpe_sn = fields.Char(string="CPE S/N NO", track_visibility="always")
    nrc = fields.Char(string="NRC", track_visibility="always")

    package = fields.Char(string="Package", track_visibility="always")
    contract_month = fields.Char(string="Contract Month", track_visibility="always")
    order_created_date = fields.Char(string="Order Created Date" , track_visibility="always")
    installation_date = fields.Date(string="Installation Date", track_visibility="always")
    cancelled_date = fields.Date(string="Cancelled Date", track_visibility="always")

    order_status = fields.Char(string="Order Status", track_visibility="always")
    sale_person = fields.Char(string="Sale Person", track_visibility="always")
    pending_date = fields.Date(string="Pending Date", track_visibility="always")
    pending_reason = fields.Text(string="Pending Reason", track_visibility="always")
    cancelled_reason = fields.Text(string="Cancelled Reason", track_visibility="always")